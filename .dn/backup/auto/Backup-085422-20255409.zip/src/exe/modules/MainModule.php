<?php
namespace exe\modules;

use std, gui, framework, exe;


class MainModule extends AbstractModule
{

}