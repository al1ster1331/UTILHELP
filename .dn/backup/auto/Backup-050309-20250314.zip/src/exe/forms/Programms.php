<?php
namespace exe\forms;

use std, gui, framework, exe;


class Programms extends AbstractForm
{

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event label3.click-Left 
     */
    function doLabel3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.click-Left 
     */
    function doLabelAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }










































    /**
     * @event image40.click-Left 
     */
    function doImage40ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image39.click-Left 
     */
    function doImage39ClickLeft(UXMouseEvent $e = null)
    {    
        
    }







































}
