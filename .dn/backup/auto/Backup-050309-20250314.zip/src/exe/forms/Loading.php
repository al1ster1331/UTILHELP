<?php
namespace exe\forms;

use std, gui, framework, exe;


class Loading extends AbstractForm
{

    /**
     * @event progressBar.construct 
     */
    function doProgressBarConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event progressBarAlt.construct 
     */
    function doProgressBarAltConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event progressBar3.construct 
     */
    function doProgressBar3Construct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event progressBar4.construct 
     */
    function doProgressBar4Construct(UXEvent $e = null)
    {    
        
    }


}
