<?php
namespace exe\modules;

use std, gui, framework, exe;


class AppModule extends AbstractModule
{

}