<?php
namespace exe\forms;

use std, gui, framework, exe;


class Drivers extends AbstractForm
{

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event label3.click-Left 
     */
    function doLabel3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.click-Left 
     */
    function doLabelAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }






















    /**
     * @event label4.click-Left 
     */
    function doLabel4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image39.click-Left 
     */
    function doImage39ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image40.click-Left 
     */
    function doImage40ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel4.mouseEnter 
     */
    function doPanel4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel4.mouseExit 
     */
    function doPanel4MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel6.mouseEnter 
     */
    function doPanel6MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel6.mouseExit 
     */
    function doPanel6MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel7.mouseEnter 
     */
    function doPanel7MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel7.mouseExit 
     */
    function doPanel7MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel8.mouseEnter 
     */
    function doPanel8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel8.mouseExit 
     */
    function doPanel8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel9.mouseEnter 
     */
    function doPanel9MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel9.mouseExit 
     */
    function doPanel9MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel3.mouseEnter 
     */
    function doPanel3MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel3.mouseExit 
     */
    function doPanel3MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel4.click-Left 
     */
    function doPanel4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel6.click-Left 
     */
    function doPanel6ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel7.click-Left 
     */
    function doPanel7ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel8.click-Left 
     */
    function doPanel8ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel9.click-Left 
     */
    function doPanel9ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event panel3.click-Left 
     */
    function doPanel3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event label11.click-Left 
     */
    function doLabel11ClickLeft(UXMouseEvent $e = null)
    {    
        
    }






















}
