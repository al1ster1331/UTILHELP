<?php
namespace exe\modules;

use std, gui, framework, exe;


class Loader extends AbstractModule
{

    /**
     * @event timer.action 
     */
    function doTimerAction(ScriptEvent $e = null)
    {    
        
    }

}
